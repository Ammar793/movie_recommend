import { Injectable } from '@angular/core';

@Injectable()
export class UpdateDatabaseService {

  constructor() { }

}
